"""Tone analysis and optimisation utilities.

The ∑YAZI‑TON_OPTIMIZER module analyses the sentiment and tone of text and
adjusts it according to predefined profiles.  This mock implementation
relies on static replacement tables loaded from a JSON file.  Real‑world
systems might use large language models to refine the output.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict


def load_tone_profiles(path: str | Path) -> Dict[str, Dict[str, str]]:
    """Load tone profiles from a JSON file.

    The file should map tone names to dictionaries of word replacements.
    Example:

    ```json
    {
      "formal": {"hi": "greetings", "bye": "farewell"},
      "informal": {"hello": "hey"}
    }
    ```
    """
    p = Path(path)
    with p.open('r', encoding='utf-8') as f:
        return json.load(f)


def analyse_tone(text: str, profiles: Dict[str, Dict[str, str]]) -> str:
    """Naively guess which tone the text most closely matches.

    We count how many words in the input appear in each profile.  The profile
    with the most matches is returned.  If no matches are found, ``"neutral"``
    is returned.
    """
    words = text.lower().split()
    best_tone = "neutral"
    best_score = 0
    for tone, replacements in profiles.items():
        score = sum(1 for w in words if w in replacements)
        if score > best_score:
            best_tone = tone
            best_score = score
    return best_tone


def optimise_tone(text: str, target_tone: str, profiles: Dict[str, Dict[str, str]]) -> str:
    """Transform the input text to match a target tone.

    Words that appear in the target profile are replaced with their mapped
    counterparts.  Unrecognised words remain unchanged.
    """
    replacements = profiles.get(target_tone, {})
    def replace_word(word: str) -> str:
        lower = word.lower()
        if lower in replacements:
            repl = replacements[lower]
            # Preserve capitalisation
            return repl.capitalize() if word[0].isupper() else repl
        return word
    transformed = [replace_word(w) for w in text.split()]
    return " ".join(transformed)
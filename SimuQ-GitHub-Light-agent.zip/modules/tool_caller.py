"""Task‑based tool selection module.

The ∑TOOL‑CALLER decides which processing engine to invoke based on the
characteristics of a request.  It examines the task description and
returns a short code representing the selected tool.
"""

from __future__ import annotations

from typing import Dict


def select_tool(task: str) -> str:
    """Return the name of the appropriate tool for a given task description.

    This function uses simple heuristics:

    - If the task mentions "image" or "picture", return ``"ocr"``.
    - If the task mentions "chart" or "plot", return ``"chart"``.
    - If the task mentions "document" or "report", return ``"document"``.
    - If the task mentions "code" or "python", return ``"python"``.
    - Otherwise return ``"default"``.
    """
    desc = task.lower()
    if any(k in desc for k in ["image", "picture", "scan"]):
        return "ocr"
    if any(k in desc for k in ["chart", "plot", "graph"]):
        return "chart"
    if any(k in desc for k in ["document", "report", "pdf"]):
        return "document"
    if any(k in desc for k in ["code", "python", "script"]):
        return "python"
    return "default"
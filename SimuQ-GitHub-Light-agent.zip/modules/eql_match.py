"""Simple mentor–mentee matching algorithm.

The ∑EQL‑MatchCore is responsible for pairing entities based on
compatibility criteria.  In this mock implementation, we compare JSON
objects on shared keys and compute a similarity score between 0 and 1.

Each candidate is scored by counting the number of matching key–value
pairs relative to the total number of keys in the entity.
"""

from __future__ import annotations

from typing import Dict, List, Tuple


def match_entities(entity: Dict[str, any], candidates: List[Dict[str, any]]) -> List[Tuple[Dict[str, any], float]]:
    """Score each candidate based on key–value similarity with ``entity``.

    Parameters
    ----------
    entity : dict
        The source entity to match against.
    candidates : list of dict
        Candidate entities to compare.

    Returns
    -------
    list of (candidate, score)
        Each tuple contains the candidate and its similarity score (0–1).
    """
    scores: List[Tuple[Dict[str, any], float]] = []
    entity_keys = set(entity.keys())
    for cand in candidates:
        if not cand:
            scores.append((cand, 0.0))
            continue
        matching = sum(1 for k in entity_keys if k in cand and cand[k] == entity[k])
        score = matching / len(entity_keys) if entity_keys else 0.0
        scores.append((cand, score))
    return scores
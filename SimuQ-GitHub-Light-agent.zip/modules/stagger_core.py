"""Strategic tagger for annotating text.

The ⧉S‑TAGGER module adds tags to text based on simple keyword rules.
Tag definitions are provided in a YAML file where each top‑level key is
the tag name and the associated value is a list of keywords that
trigger that tag.  When a keyword appears in the input text, the
corresponding tag is added to the output.
"""

from __future__ import annotations

import yaml
from pathlib import Path
from typing import Dict, List, Set


def load_tag_definitions(path: str | Path) -> Dict[str, List[str]]:
    """Load tag definitions from a YAML file."""
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def tag_text(text: str, tag_defs: Dict[str, List[str]]) -> Set[str]:
    """Return a set of tags that apply to the given text."""
    tags: Set[str] = set()
    words = {w.lower() for w in text.split()}
    for tag, keywords in tag_defs.items():
        if any(kw.lower() in words for kw in keywords):
            tags.add(tag)
    return tags
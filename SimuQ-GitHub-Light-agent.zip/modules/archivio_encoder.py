"""Symbolic archive encoder for SimuQ‑GitHub‑Light.

The ∆ARCHIVIO‑CODE module converts human‑readable text into a simple
symbolic format and vice versa.  Here we represent each character in
hexadecimal form, separated by spaces.  A real implementation might use
custom binary encodings or semantic markers.
"""

from __future__ import annotations

from pathlib import Path
from typing import List


def encode_to_symbolic(text: str) -> str:
    """Encode text to a space‑separated sequence of hexadecimal codes."""
    return " ".join(f"{ord(ch):02x}" for ch in text)


def decode_from_symbolic(sym: str) -> str:
    """Decode a space‑separated sequence of hexadecimal codes back to text."""
    chars: List[str] = []
    for code in sym.split():
        try:
            chars.append(chr(int(code, 16)))
        except ValueError:
            chars.append('?')  # unknown token
    return "".join(chars)


def write_sym_file(text: str, path: str | Path) -> None:
    """Write the symbolic representation of ``text`` to a `.sym` file."""
    p = Path(path)
    p.write_text(encode_to_symbolic(text), encoding='utf-8')


def read_sym_file(path: str | Path) -> str:
    """Read a `.sym` file and return the decoded text."""
    p = Path(path)
    sym = p.read_text(encoding='utf-8')
    return decode_from_symbolic(sym)
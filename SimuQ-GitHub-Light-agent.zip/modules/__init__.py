"""Collection of example modules for SimuQ‑GitHub‑Light.

This package bundles independent utilities that together illustrate how
SimuQ can process and transform information.  Each module is designed to
be simple and easily customisable.
"""
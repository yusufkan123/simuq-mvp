"""Error tolerance and fallback logic for SimuQ‑GitHub‑Light.

The ∑ERR‑SAFE module provides defensive programming utilities.  In a fully
featured system this would include comprehensive tracing, multiple
alternative reasoning paths and explanatory notes.  Here we implement a
simple function to wrap arbitrary callables with a fallback and record
a trace of exceptions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Tuple
import traceback


@dataclass
class FallbackResult:
    """Container for a result or a fallback.

    Attributes
    ----------
    result: Any
        The primary result or the fallback result.
    used_fallback: bool
        Whether the fallback was used.
    trace: Optional[str]
        Traceback information when an exception occurs.
    """
    result: Any
    used_fallback: bool
    trace: Optional[str] = None


def try_with_fallback(
    primary_func: Callable[..., Any],
    fallback_func: Callable[..., Any],
    *args: Any,
    **kwargs: Any,
) -> FallbackResult:
    """Execute ``primary_func`` and fall back to ``fallback_func`` on error.

    Parameters
    ----------
    primary_func : Callable
        Function to execute initially.
    fallback_func : Callable
        Function to call if the primary function raises an exception.
    *args, **kwargs
        Arguments forwarded to both functions.

    Returns
    -------
    FallbackResult
        Structured result describing whether the fallback was invoked.
    """
    try:
        result = primary_func(*args, **kwargs)
        return FallbackResult(result=result, used_fallback=False, trace=None)
    except Exception:
        tb = traceback.format_exc()
        fallback_result = fallback_func(*args, **kwargs)
        return FallbackResult(result=fallback_result, used_fallback=True, trace=tb)
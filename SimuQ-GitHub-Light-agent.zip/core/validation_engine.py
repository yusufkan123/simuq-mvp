"""Mock implementation of the ∑REAL‑VALIDATION‑PROTOCOL.

This module demonstrates a lightweight protocol used to validate and
corroborate the outputs of reasoning systems.  In the private SimuQ
system, this protocol combines scientific evaluation, effect‑based testing
and intuitive heuristics.  Here we provide simple placeholders that you
can extend with your own logic.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class ValidationResult:
    """Container for validation results.

    Attributes
    ----------
    success: bool
        Whether the validation passed.
    messages: List[str]
        Human‑readable explanations of the validation outcome.
    details: Optional[Dict[str, Any]]
        Additional structured information about the validation process.
    """

    success: bool
    messages: List[str]
    details: Optional[Dict[str, Any]] = None


class RealValidationProtocol:
    """Simplified validation engine.

    This engine exposes two primary methods: ``validate_scientific`` and
    ``validate_intuitive``.  The first checks that results satisfy a
    deterministic predicate, while the second uses a heuristic scoring
    mechanism.  The union of these validations is returned by
    ``validate``.
    """

    def __init__(self, threshold: float = 0.5) -> None:
        self.threshold = threshold

    def validate_scientific(self, data: Any) -> ValidationResult:
        """Perform a deterministic validation of the data.

        In this mock implementation, numeric inputs greater than 0 are
        considered valid.  Non‑numeric inputs always pass.

        Parameters
        ----------
        data : Any
            The result to be validated.

        Returns
        -------
        ValidationResult
            Outcome of the validation.
        """
        if isinstance(data, (int, float)):
            success = data > 0
            messages = [
                f"Scientific check: value {'passes' if success else 'fails'} (>{0})."
            ]
        else:
            success = True
            messages = ["Scientific check: non‑numeric data automatically passes."]
        return ValidationResult(success=success, messages=messages)

    def validate_intuitive(self, data: Any) -> ValidationResult:
        """Perform an intuitive heuristic validation.

        This mock method assigns a pseudo‑random score based on the hash of
        the data.  If the score exceeds ``self.threshold``, the result is
        considered intuitively plausible.
        """
        # Derive a pseudo‑random score between 0 and 1 from the built‑in hash
        score = (hash(data) % 1000) / 1000.0
        success = score >= self.threshold
        messages = [
            f"Intuitive check: computed heuristic score {score:.3f}",
            f"Threshold: {self.threshold:.2f} — result {'passes' if success else 'fails'}.",
        ]
        return ValidationResult(success=success, messages=messages, details={"score": score})

    def validate(self, data: Any) -> ValidationResult:
        """Run both scientific and intuitive validations.

        Returns a combined ``ValidationResult`` where ``success`` is
        ``True`` only if both checks pass.
        """
        sci = self.validate_scientific(data)
        intu = self.validate_intuitive(data)
        success = sci.success and intu.success
        messages = sci.messages + intu.messages
        details = {"scientific": sci.details, "intuitive": intu.details}
        return ValidationResult(success=success, messages=messages, details=details)
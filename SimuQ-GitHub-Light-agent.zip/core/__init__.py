"""Core package for SimuQ‑GitHub‑Light.

This package contains mock implementations of core services used by the
private SimuQ‑X_YK system.  They provide simple, illustrative examples of
how an actual validation engine, identity lock and error handling layer
could be structured in Python.
"""
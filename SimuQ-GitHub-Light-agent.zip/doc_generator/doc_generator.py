"""Simple document generator.

The ∇DOC_GENERATOR module takes plain text and produces formatted documents in
Markdown or PDF format.  For PDF generation it relies on the ``reportlab``
library; if that library is not installed, a ``RuntimeError`` is raised.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

def generate_document(text: str, output_path: str | Path, fmt: str = "md") -> Path:
    """Generate a document from text.

    Parameters
    ----------
    text : str
        The body of the document.
    output_path : str or Path
        Where to save the document.
    fmt : str, optional
        The output format ("md" or "pdf").  Defaults to "md".

    Returns
    -------
    Path
        Path to the generated file.
    """
    p = Path(output_path)
    fmt = fmt.lower()
    if fmt == "md":
        p.write_text(text, encoding='utf-8')
        return p
    elif fmt == "pdf":
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.pdfgen import canvas
        except ImportError as e:
            raise RuntimeError("PDF generation requires reportlab; please install it.") from e
        c = canvas.Canvas(str(p), pagesize=letter)
        width, height = letter
        # Simple text wrapping: split text by lines and draw each line
        lines = text.split("\n")
        y = height - 72  # margin from top
        for line in lines:
            c.drawString(72, y, line)
            y -= 14
            if y < 72:
                c.showPage()
                y = height - 72
        c.save()
        return p
    else:
        raise ValueError(f"Unsupported format: {fmt}")
---
title: "SimuQ Document"
date: "{{ date }}"
---

## Introduction

This document was generated using the SimuQ‑GitHub‑Light document generator.  Replace the
content of this section with your own text.  The template front matter can be
parsed by static site generators or markdown engines that support YAML metadata.

## Body

{{ content }}

## Conclusion

Summarise your findings here and include any next steps or recommendations.
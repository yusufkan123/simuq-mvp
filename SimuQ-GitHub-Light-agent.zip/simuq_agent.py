"""Command‑line agent demonstrating the SimuQ‑GitHub‑Light modules.

This script ties together the various mock modules contained in this
repository.  It provides a simple interface for testing functionality
such as tone optimisation, entity matching, symbolic encoding,
tagging, validation, echo generation and document creation.  By
running this script with the appropriate flags you can see how the
components interact.

Example usage::

    python simuq_agent.py --task tone --input "Hello world" --target-tone formal

    python simuq_agent.py --task match

    python simuq_agent.py --task encode --input "Example"

    python simuq_agent.py --task document --input "Report body" --fmt pdf --output report.pdf
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict

# Import modules from this package
from core.validation_engine import RealValidationProtocol
from core.core_lock_interface import load_identity_layer, apply_identity_filter
from core.error_safe_core import try_with_fallback
from modules.eql_match import match_entities
from modules.tone_optimizer import load_tone_profiles, analyse_tone, optimise_tone
from modules.archivio_encoder import encode_to_symbolic, decode_from_symbolic, write_sym_file, read_sym_file
from modules.stagger_core import load_tag_definitions, tag_text
from modules.sym_echo import generate_echo
from modules.tool_caller import select_tool
from doc_generator.doc_generator import generate_document

EXAMPLES_DIR = Path(__file__).parent / "examples"


def run_tone(input_text: str, target_tone: str | None = None) -> None:
    """Analyse and optionally optimise the tone of a string."""
    profiles_path = EXAMPLES_DIR / "tone_profiles.json"
    profiles = load_tone_profiles(profiles_path)
    detected = analyse_tone(input_text, profiles)
    print(f"Detected tone: {detected}")
    if target_tone:
        transformed = optimise_tone(input_text, target_tone, profiles)
        print(f"Transformed text [{target_tone}]: {transformed}")


def run_match() -> None:
    """Run a sample entity matching using the example JSON file."""
    sample_path = EXAMPLES_DIR / "matching_samples.json"
    with open(sample_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    entity = data["entity"]
    candidates = data["candidates"]
    scores = match_entities(entity, candidates)
    for cand, score in scores:
        print(f"Candidate {cand} -> score {score:.2f}")


def run_encode(input_text: str) -> None:
    """Encode text into a symbolic format and decode it back."""
    sym = encode_to_symbolic(input_text)
    print(f"Encoded: {sym}")
    decoded = decode_from_symbolic(sym)
    print(f"Decoded: {decoded}")


def run_tag(input_text: str) -> None:
    """Tag text using the example tag definitions."""
    tag_defs_path = EXAMPLES_DIR / "tag_definitions.yaml"
    tag_defs = load_tag_definitions(tag_defs_path)
    tags = tag_text(input_text, tag_defs)
    print(f"Tags: {', '.join(sorted(tags)) if tags else '(none)'}")


def run_validate(input_value: Any) -> None:
    """Validate an input using the RealValidationProtocol."""
    v = RealValidationProtocol()
    result = v.validate(input_value)
    print(f"Success: {result.success}")
    for msg in result.messages:
        print(f"  - {msg}")


def run_echo(value: Any) -> None:
    """Generate a symbolic echo for an input."""
    echo = generate_echo(value)
    print(json.dumps(echo, indent=2))


def run_document(input_text: str, fmt: str, output: str) -> None:
    """Generate a document from text."""
    output_path = Path(output)
    result_path = generate_document(input_text, output_path, fmt)
    print(f"Document saved to {result_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="SimuQ demo agent")
    parser.add_argument("--task", required=True, choices=[
        "tone", "match", "encode", "tag", "validate", "echo", "document"
    ], help="Task to perform")
    parser.add_argument("--input", help="Input text or value for tasks that require it")
    parser.add_argument("--target-tone", help="Target tone for tone optimisation")
    parser.add_argument("--fmt", default="md", help="Output format for document generation (md or pdf)")
    parser.add_argument("--output", default="output.md", help="Output file path for document generation")
    args = parser.parse_args()

    task = args.task
    if task == "tone":
        if not args.input:
            parser.error("--input is required for tone task")
        run_tone(args.input, args.target_tone)
    elif task == "match":
        run_match()
    elif task == "encode":
        if not args.input:
            parser.error("--input is required for encode task")
        run_encode(args.input)
    elif task == "tag":
        if not args.input:
            parser.error("--input is required for tag task")
        run_tag(args.input)
    elif task == "validate":
        if not args.input:
            parser.error("--input is required for validate task")
        # Try to interpret input as JSON or number
        try:
            value: Any = json.loads(args.input)
        except json.JSONDecodeError:
            try:
                value = float(args.input)
            except ValueError:
                value = args.input
        run_validate(value)
    elif task == "echo":
        if not args.input:
            parser.error("--input is required for echo task")
        # No conversion, just pass as string
        run_echo(args.input)
    elif task == "document":
        if not args.input:
            parser.error("--input is required for document task")
        run_document(args.input, args.fmt, args.output)
    else:
        parser.error(f"Unknown task: {task}")


if __name__ == "__main__":
    main()